<?php
namespace api\modules\v1\models;

use common\models\Country;
use common\models\Wishlist;
use Yii;
use yii\base\NotSupportedException;
use yii\behaviors\TimestampBehavior;
use yii\filters\RateLimitInterface;

use yii\db\ActiveRecord;
use yii\web\IdentityInterface;

/**
 * User model
 *
 * @property integer $id
 * @property string $username
 * @property string $password_hash
 * @property string $password_reset_token
 * @property string $email
 * @property string $auth_key
 * @property integer $status
 * @property integer $created_at
 * @property integer $updated_at
 * @property string $password write-only password
 * @property int $id_country
 */
class User extends ActiveRecord implements IdentityInterface, RateLimitInterface
{
    const STATUS_DELETED = 0;
    const STATUS_BLOCK = 5;
    const STATUS_ACTIVE = 10;


    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return '{{%user}}';
    }

    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            TimestampBehavior::className(),
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [

            [['username', 'auth_key', 'password_hash', 'email'], 'required'],
            [['status', 'created_at', 'updated_at', 'id_country'], 'integer'],
            [['username', 'password_hash', 'password_reset_token', 'email'], 'string', 'max' => 255],
            [['auth_key'], 'string', 'max' => 32],
            [['username'], 'unique'],
            [['email'], 'unique'],
            [['password_reset_token'], 'unique'],

            ['status', 'default', 'value' => self::STATUS_ACTIVE],
            ['status', 'in', 'range' => [self::STATUS_ACTIVE, self::STATUS_DELETED]],
        ];
    }

    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'username' => 'Username',
            'auth_key' => 'Auth Key',
            'password_hash' => 'Password',
            'password_reset_token' => 'Password Reset Token',
            'email' => 'Email',
            'status' => 'Status',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'id_country' => 'Country',
        ];

    }


    public function getCountry()
    {
        return $this->hasOne(Country::className(), ['id_country' => 'id_country']);
    }

    public function getTrips()
    {
        return $this->hasMany(Trip::className(), ['id' => 'id_user']);
    }

    public function getReviews()
    {
        return $this->hasMany(Review::className(), ['id' => 'id_user']);
    }
    public function getWishlist()
    {
        $data = Wishlist::find()->where(['id_user'=>$this->id])->all();
        return $data;
    }

    public function getCountriesVisited(){

        $data = Trip::find()->select('id_country')->where(['id_user'=>$this->id])->distinct()->count();
        return $data;
    }

    public function getPercentageWorld(){

        $data = $this->getCountriesVisited()/195;
        return $data;
    }
    /**
     * {@inheritdoc}
     */
    public static function findIdentity($id)
    {
        //return static::findOne(['id' => $id, 'status' => self::STATUS_ACTIVE]);
        return static::findOne($id);
    }

    /**
     * {@inheritdoc}
     */
    public static function findIdentityByAccessToken($token, $type = null)
    {
        return static::findOne(['auth_key'=>$token]);
        //return null;
       // throw new NotSupportedException('"findIdentityByAccessToken" is not implemented.');
    }

    /**
     * Finds user by username
     *
     * @param string $username
     * @return static|null
     */
    public static function findByUsername($username)
    {
        return static::findOne(['username' => $username, 'status' => self::STATUS_ACTIVE]);
        //$user = self::find()->where(["username"=>$username])->one();

//        if(!count($user)){
//            return null;
//        }
        return new static($user);
    }

    /**
     * Finds user by password reset token
     *
     * @param string $token password reset token
     * @return static|null
     */
    public static function findByPasswordResetToken($token)
    {
        if (!static::isPasswordResetTokenValid($token)) {
            return null;
        }

        return static::findOne([
            'password_reset_token' => $token,
            'status' => self::STATUS_ACTIVE,
        ]);
    }

    /**
     * Finds out if password reset token is valid
     *
     * @param string $token password reset token
     * @return bool
     */
    public static function isPasswordResetTokenValid($token)
    {
        if (empty($token)) {
            return false;
        }

        $timestamp = (int) substr($token, strrpos($token, '_') + 1);
        $expire = Yii::$app->params['user.passwordResetTokenExpire'];
        return $timestamp + $expire >= time();
    }

    /**
     * {@inheritdoc}
     */
    public function getId()
    {
        //return $this->getPrimaryKey();
        return $this->id;
    }

    /**
     * {@inheritdoc}
     */
    public function getAuthKey()
    {
        return $this->auth_key;
        //return null;
    }

    /**
     * {@inheritdoc}
     */
    public function validateAuthKey($authKey)
    {
        return $this->getAuthKey() === $authKey;
        //return null;
    }

    /**
     * Validates password
     *
     * @param string $password password to validate
     * @return bool if password provided is valid for current user
     */

    public function validatePassword($password)
    {
        return Yii::$app->security->validatePassword($password, $this->password_hash);
    }

    /**
     * Generates password hash from password and sets it to the model
     *
     * @param string $password
     */
    public function setPassword($password)
    {
        $this->password_hash = Yii::$app->security->generatePasswordHash($password);
    }

    /**
     * Generates "remember me" authentication key
     */
    public function generateAuthKey()
    {
        $this->auth_key = Yii::$app->security->generateRandomString();
    }

    /**
     * Generates new password reset token
     */
    public function generatePasswordResetToken()
    {
        $this->password_reset_token = Yii::$app->security->generateRandomString() . '_' . time();
    }

    /**
     * Removes password reset token
     */
    public function removePasswordResetToken()
    {
        $this->password_reset_token = null;
    }
    //https://www.yiiframework.com/doc/guide/2.0/en/rest-rate-limiting
    /**
     * Lets the system know how many requests are allowed for this user in a given period of time
     *
     * @param yii\web\Request $request
     * @param string $action
     * @return array
     */
    public function getRateLimit($request, $action)
    {
        // Tuple is num_requests, period_in_seconds
        return [100, 10]; // $rateLimit requests per second
    }
    /**
     * Return the current rate limit values for this user
     *
     * @param yii\web\Request $request
     * @param string $action
     * @return array
     */
    public function loadAllowance($request, $action)
    {
        //$allowance = 100; // fetch the allowance from a datasource.
        return [100,time()];
    }
    /**
     * Update this user's rate limit allowances based on a request.
     *
     * Note, this method can use the request and action to make decisions about
     * if and what allowance values to save
     *
     * @param yii\web\Request $request The api request
     * @param string $action The action being called
     * @param int $allowance The updated allowance amount
     * @param int $timestamp The unix timestamp of the request
     */
    public function saveAllowance($request, $action, $allowance, $timestamp)
    {

        return true;
    }
}
